package com.google.adk.plugins.recordings;

import com.google.adk.models.LlmRequest;
import com.google.adk.models.LlmResponse;
import java.util.List;
import java.util.Optional;
import javax.annotation.processing.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_LlmRecording extends LlmRecording {

  private final Optional<LlmRequest> llmRequest;

  private final Optional<List<LlmResponse>> llmResponses;

  private AutoValue_LlmRecording(
      Optional<LlmRequest> llmRequest,
      Optional<List<LlmResponse>> llmResponses) {
    this.llmRequest = llmRequest;
    this.llmResponses = llmResponses;
  }

  @Override
  public Optional<LlmRequest> llmRequest() {
    return llmRequest;
  }

  @Override
  public Optional<List<LlmResponse>> llmResponses() {
    return llmResponses;
  }

  @Override
  public String toString() {
    return "LlmRecording{"
        + "llmRequest=" + llmRequest + ", "
        + "llmResponses=" + llmResponses
        + "}";
  }

  @Override
  public boolean equals(@org.jspecify.annotations.Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof LlmRecording) {
      LlmRecording that = (LlmRecording) o;
      return this.llmRequest.equals(that.llmRequest())
          && this.llmResponses.equals(that.llmResponses());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= llmRequest.hashCode();
    h$ *= 1000003;
    h$ ^= llmResponses.hashCode();
    return h$;
  }

  static final class Builder extends LlmRecording.Builder {
    private Optional<LlmRequest> llmRequest = Optional.empty();
    private Optional<List<LlmResponse>> llmResponses = Optional.empty();
    Builder() {
    }
    @Override
    public LlmRecording.Builder llmRequest(@javax.annotation.Nullable LlmRequest llmRequest) {
      this.llmRequest = Optional.ofNullable(llmRequest);
      return this;
    }
    @Override
    public LlmRecording.Builder llmResponses(@javax.annotation.Nullable List<LlmResponse> llmResponses) {
      this.llmResponses = Optional.ofNullable(llmResponses);
      return this;
    }
    @Override
    public LlmRecording build() {
      return new AutoValue_LlmRecording(
          this.llmRequest,
          this.llmResponses);
    }
  }

}
