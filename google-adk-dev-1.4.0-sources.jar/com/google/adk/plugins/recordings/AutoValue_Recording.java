package com.google.adk.plugins.recordings;

import java.util.Optional;
import javax.annotation.processing.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_Recording extends Recording {

  private final int userMessageIndex;

  private final String agentName;

  private final Optional<LlmRecording> llmRecording;

  private final Optional<ToolRecording> toolRecording;

  private AutoValue_Recording(
      int userMessageIndex,
      String agentName,
      Optional<LlmRecording> llmRecording,
      Optional<ToolRecording> toolRecording) {
    this.userMessageIndex = userMessageIndex;
    this.agentName = agentName;
    this.llmRecording = llmRecording;
    this.toolRecording = toolRecording;
  }

  @Override
  public int userMessageIndex() {
    return userMessageIndex;
  }

  @Override
  public String agentName() {
    return agentName;
  }

  @Override
  public Optional<LlmRecording> llmRecording() {
    return llmRecording;
  }

  @Override
  public Optional<ToolRecording> toolRecording() {
    return toolRecording;
  }

  @Override
  public String toString() {
    return "Recording{"
        + "userMessageIndex=" + userMessageIndex + ", "
        + "agentName=" + agentName + ", "
        + "llmRecording=" + llmRecording + ", "
        + "toolRecording=" + toolRecording
        + "}";
  }

  @Override
  public boolean equals(@org.jspecify.annotations.Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof Recording) {
      Recording that = (Recording) o;
      return this.userMessageIndex == that.userMessageIndex()
          && this.agentName.equals(that.agentName())
          && this.llmRecording.equals(that.llmRecording())
          && this.toolRecording.equals(that.toolRecording());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= userMessageIndex;
    h$ *= 1000003;
    h$ ^= agentName.hashCode();
    h$ *= 1000003;
    h$ ^= llmRecording.hashCode();
    h$ *= 1000003;
    h$ ^= toolRecording.hashCode();
    return h$;
  }

  static final class Builder extends Recording.Builder {
    private int userMessageIndex;
    private @org.jspecify.annotations.Nullable String agentName;
    private Optional<LlmRecording> llmRecording = Optional.empty();
    private Optional<ToolRecording> toolRecording = Optional.empty();
    private byte set$0;
    Builder() {
    }
    @Override
    public Recording.Builder userMessageIndex(int userMessageIndex) {
      this.userMessageIndex = userMessageIndex;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    public Recording.Builder agentName(String agentName) {
      if (agentName == null) {
        throw new NullPointerException("Null agentName");
      }
      this.agentName = agentName;
      return this;
    }
    @Override
    public Recording.Builder llmRecording(@javax.annotation.Nullable LlmRecording llmRecording) {
      this.llmRecording = Optional.ofNullable(llmRecording);
      return this;
    }
    @Override
    public Recording.Builder toolRecording(@javax.annotation.Nullable ToolRecording toolRecording) {
      this.toolRecording = Optional.ofNullable(toolRecording);
      return this;
    }
    @Override
    public Recording build() {
      if (set$0 != 1
          || this.agentName == null) {
        StringBuilder missing = new StringBuilder();
        if ((set$0 & 1) == 0) {
          missing.append(" userMessageIndex");
        }
        if (this.agentName == null) {
          missing.append(" agentName");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_Recording(
          this.userMessageIndex,
          this.agentName,
          this.llmRecording,
          this.toolRecording);
    }
  }

}
