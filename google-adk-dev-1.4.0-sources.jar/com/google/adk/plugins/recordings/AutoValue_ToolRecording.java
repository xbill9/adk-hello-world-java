package com.google.adk.plugins.recordings;

import com.google.genai.types.FunctionCall;
import com.google.genai.types.FunctionResponse;
import java.util.Optional;
import javax.annotation.processing.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ToolRecording extends ToolRecording {

  private final Optional<FunctionCall> toolCall;

  private final Optional<FunctionResponse> toolResponse;

  private AutoValue_ToolRecording(
      Optional<FunctionCall> toolCall,
      Optional<FunctionResponse> toolResponse) {
    this.toolCall = toolCall;
    this.toolResponse = toolResponse;
  }

  @Override
  public Optional<FunctionCall> toolCall() {
    return toolCall;
  }

  @Override
  public Optional<FunctionResponse> toolResponse() {
    return toolResponse;
  }

  @Override
  public String toString() {
    return "ToolRecording{"
        + "toolCall=" + toolCall + ", "
        + "toolResponse=" + toolResponse
        + "}";
  }

  @Override
  public boolean equals(@org.jspecify.annotations.Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ToolRecording) {
      ToolRecording that = (ToolRecording) o;
      return this.toolCall.equals(that.toolCall())
          && this.toolResponse.equals(that.toolResponse());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= toolCall.hashCode();
    h$ *= 1000003;
    h$ ^= toolResponse.hashCode();
    return h$;
  }

  static final class Builder extends ToolRecording.Builder {
    private Optional<FunctionCall> toolCall = Optional.empty();
    private Optional<FunctionResponse> toolResponse = Optional.empty();
    Builder() {
    }
    @Override
    public ToolRecording.Builder toolCall(@javax.annotation.Nullable FunctionCall toolCall) {
      this.toolCall = Optional.ofNullable(toolCall);
      return this;
    }
    @Override
    public ToolRecording.Builder toolResponse(@javax.annotation.Nullable FunctionResponse toolResponse) {
      this.toolResponse = Optional.ofNullable(toolResponse);
      return this;
    }
    @Override
    public ToolRecording build() {
      return new AutoValue_ToolRecording(
          this.toolCall,
          this.toolResponse);
    }
  }

}
