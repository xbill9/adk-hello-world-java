package com.google.adk.plugins.recordings;

import com.google.common.collect.ImmutableList;
import java.util.List;
import javax.annotation.processing.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_Recordings extends Recordings {

  private final ImmutableList<Recording> recordings;

  private AutoValue_Recordings(
      ImmutableList<Recording> recordings) {
    this.recordings = recordings;
  }

  @Override
  public ImmutableList<Recording> recordings() {
    return recordings;
  }

  @Override
  public String toString() {
    return "Recordings{"
        + "recordings=" + recordings
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof Recordings) {
      Recordings that = (Recordings) o;
      return this.recordings.equals(that.recordings());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= recordings.hashCode();
    return h$;
  }

  static final class Builder extends Recordings.Builder {
    private @Nullable ImmutableList<Recording> recordings;
    Builder() {
    }
    @Override
    public Recordings.Builder recordings(List<Recording> recordings) {
      this.recordings = ImmutableList.copyOf(recordings);
      return this;
    }
    @Override
    public Recordings build() {
      if (this.recordings == null) {
        String missing = " recordings";
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_Recordings(
          this.recordings);
    }
  }

}
