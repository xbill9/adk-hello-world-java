package com.google.adk.web.service;

import java.util.Optional;
import javax.annotation.processing.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ApiServerSpanExporterConfig extends ApiServerSpanExporterConfig {

  private final Optional<Integer> maxSpansToKeep;

  private AutoValue_ApiServerSpanExporterConfig(
      Optional<Integer> maxSpansToKeep) {
    this.maxSpansToKeep = maxSpansToKeep;
  }

  @Override
  public Optional<Integer> maxSpansToKeep() {
    return maxSpansToKeep;
  }

  @Override
  public String toString() {
    return "ApiServerSpanExporterConfig{"
        + "maxSpansToKeep=" + maxSpansToKeep
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ApiServerSpanExporterConfig) {
      ApiServerSpanExporterConfig that = (ApiServerSpanExporterConfig) o;
      return this.maxSpansToKeep.equals(that.maxSpansToKeep());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= maxSpansToKeep.hashCode();
    return h$;
  }

  static final class Builder extends ApiServerSpanExporterConfig.Builder {
    private Optional<Integer> maxSpansToKeep = Optional.empty();
    Builder() {
    }
    @Override
    public ApiServerSpanExporterConfig.Builder maxSpansToKeep(Optional<Integer> maxSpansToKeep) {
      if (maxSpansToKeep == null) {
        throw new NullPointerException("Null maxSpansToKeep");
      }
      this.maxSpansToKeep = maxSpansToKeep;
      return this;
    }
    @Override
    ApiServerSpanExporterConfig autoBuild() {
      return new AutoValue_ApiServerSpanExporterConfig(
          this.maxSpansToKeep);
    }
  }

}
